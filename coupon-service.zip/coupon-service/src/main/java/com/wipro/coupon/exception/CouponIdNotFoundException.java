package com.wipro.coupon.exception;

public class CouponIdNotFoundException extends RuntimeException {
	private int id;
	
	public CouponIdNotFoundException(int id) {
		this.id=id;
	}
	
	@Override
	public String toString() {
		return "Employee Id" + id + "is not found";
	}


}
