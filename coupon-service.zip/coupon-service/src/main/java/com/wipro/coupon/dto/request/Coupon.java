package com.wipro.coupon.dto.request;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class Coupon {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Schema(accessMode=Schema.AccessMode.READ_ONLY)
	private int Id;
	@Column(name="code")
	private String code;
	@Column(name="discount")
	private int discount;
	public int getId() {
		return Id;
	}
	public void setId(int Id) {
		this.Id = Id;
	}
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	public int getDiscount(int discount) {
		return discount;
	}
	public void setDiscount(int discount) {
		this.discount = discount;
	}
}
