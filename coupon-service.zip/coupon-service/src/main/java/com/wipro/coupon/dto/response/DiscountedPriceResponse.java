package com.wipro.coupon.dto.response;

public class DiscountedPriceResponse {
	
	private String couponCode;
	private String productName;
	private double originalPrice;
	private double discountPercent;
	private double finalPrice;
	
	public DiscountedPriceResponse(String couponcode,String productName,double originalPrice,double discountPercent,double finalPrice) {
		this.couponCode= couponCode;
		this.productName=productName;
		this.originalPrice=originalPrice;
		this.discountPercent=discountPercent;
		this.finalPrice=finalPrice;
	}
	
	public String getCouponCode() {
		return couponCode;
	}
	public String getProductName() {
		return productName;
	}
	public double getOriginalPrice() {
		return originalPrice;
	}
	public double getDiscountPercent() {
		return discountPercent;
	}
	public double getFinalPrice() {
		return finalPrice;
	}

}
