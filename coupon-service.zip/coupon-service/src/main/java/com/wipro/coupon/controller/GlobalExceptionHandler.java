package com.wipro.coupon.controller;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import com.wipro.coupon.dto.response.ErrorResponse;
import com.wipro.coupon.exception.CouponIdNotFoundException;
//import com.wipro.coupon.exception.EmployeeIdNotFoundException;
@RestControllerAdvice
public class GlobalExceptionHandler {
	@ExceptionHandler(CouponIdNotFoundException.class)
	public ResponseEntity<ErrorResponse> handleEmployeeIdNotException(	CouponIdNotFoundException ex){
		
		ErrorResponse errorResponse=new ErrorResponse();
		errorResponse.setMessage(ex.getMessage());
		errorResponse.setStatus(HttpStatus.NOT_FOUND);
		
		return new ResponseEntity<ErrorResponse>(errorResponse,HttpStatus.NOT_FOUND);
	}

}
