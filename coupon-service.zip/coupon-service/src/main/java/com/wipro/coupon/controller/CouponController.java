package com.wipro.coupon.controller;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.wipro.coupon.client.ProductClient;
import com.wipro.coupon.dto.request.Coupon;
import com.wipro.coupon.service.CouponService;
@Tag(name="Coupon",description="Coupon management APIs")
@RequestMapping("api/v1/coupons")
@RestController
public class CouponController {
	@Autowired
	private CouponService couponService;
	private ProductClient productClient;
	public CouponController(@Autowired CouponService couponservice, 
							@Autowired ProductClient productClient) {
		super();
		this.couponService = couponService;
		this.productClient= productClient;
	}
	
	@PostMapping
	
	public ResponseEntity<Coupon> saveCoupon(@RequestBody Coupon coupon){
		return new ResponseEntity<Coupon>(couponService.saveCoupon(coupon),HttpStatus.CREATED);
	}
	@Operation(summary="Get coupon by id")
	@GetMapping("/{id}")
	public ResponseEntity<Coupon> getCouponByid(@PathVariable int id){
		return new ResponseEntity<Coupon>(couponService.findById(id),HttpStatus.OK);
	}
	
	@GetMapping
	public ResponseEntity<List<Coupon>>getAllCoupon(){
		return new ResponseEntity<List<Coupon>>(couponService.findAll(),HttpStatus.OK);
	}
	@Operation(summary="Get employee by code")
	@GetMapping("/code/{code}")
	public ResponseEntity<Coupon>findByCode(@PathVariable String code){
		
		return new ResponseEntity<Coupon>(couponService.findByCode(code),HttpStatus.OK);
	}
	
}
