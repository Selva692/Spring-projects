package com.wipro.coupon.controller;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.wipro.coupon.dto.request.Coupon;
import com.wipro.coupon.exception.CouponIdNotFoundException;
import com.wipro.coupon.service.CouponService;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.http.MediaType;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.web.servlet.MockMvc;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;
import static org.hamcrest.collection.IsCollectionWithSize.hasSize;
import java.util.Arrays;
import java.util.List;
import java.util.Random;
import java.util.UUID;

@WebMvcTest(CouponController.class)
class CouponControllerTest {

	@MockitoBean
    //@MockBean // used to create mock object /dummy object
    private CouponService couponService;

    @Autowired
    private MockMvc mockMvc; // to test the API 

    @Autowired
    private ObjectMapper objectMapper;
    private final Random random=new Random();
    private String randomText(int length) {
    	return UUID.randomUUID().toString().replace("-", "").substring(0,length);
    }
    
	private Coupon testCreateCoupon() {
    	Coupon coupon = new Coupon();
		coupon.setId(random.nextInt(1000)+1);
		coupon.setCode(randomText(8));
		coupon.setDiscount(random.nextInt(1000)+1);
    	return coupon;
    }
        @Test // test case
        void testSaveCoupon() throws Exception{
        	Coupon actualCouponRequestBody=testCreateCoupon();
        when(couponService.saveCoupon(any(Coupon.class))).thenReturn(actualCouponRequestBody);

        // act & assert
        mockMvc.perform(post("/api/v1/employees")
                    .contentType(MediaType.APPLICATION_JSON)
                    .content(objectMapper.writeValueAsString(actualCouponRequestBody)))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.code").value(actualCouponRequestBody.getCode()))
                .andExpect(jsonPath("$.discount").value(actualCouponRequestBody.getDiscount(0)));
}
}
