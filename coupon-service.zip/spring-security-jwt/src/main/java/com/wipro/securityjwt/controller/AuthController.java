package com.wipro.securityjwt.controller;
import com.wipro.securityjwt.dto.ApiResponse;
import com.wipro.securityjwt.dto.JwtResponse;
import com.wipro.securityjwt.dto.LoginRequest;
import com.wipro.securityjwt.dto.RegisterRequest;
import com.wipro.securityjwt.service.AuthService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

/**
 * Public authentication endpoints - no JWT required.
 * /api/auth/** is whitelisted in SecurityConfig.
 */
@RestController
@RequestMapping("/api/auth")
@RequiredArgsConstructor

public class AuthController {
	 private final AuthService authService;

	    @PostMapping("/register")
	    public ResponseEntity<ApiResponse> register(@Valid @RequestBody RegisterRequest request) {
	        authService.register(request);
	        return ResponseEntity.status(HttpStatus.CREATED)
	                .body(new ApiResponse(true, "User registered successfully"));
	    }

	    @PostMapping("/login")
	    public ResponseEntity<JwtResponse> login(@Valid @RequestBody LoginRequest request) {
	        JwtResponse response = authService.login(request);
	        return ResponseEntity.ok(response);
	    }


}
