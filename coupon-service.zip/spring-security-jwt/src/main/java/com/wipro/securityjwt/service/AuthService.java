package com.wipro.securityjwt.service;
import com.wipro.securityjwt.dto.JwtResponse;
import com.wipro.securityjwt.dto.LoginRequest;
import com.wipro.securityjwt.dto.RegisterRequest;


public interface AuthService {
	 void register(RegisterRequest request);

	    JwtResponse login(LoginRequest request);


}
