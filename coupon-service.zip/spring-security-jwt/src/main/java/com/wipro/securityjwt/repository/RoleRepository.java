package com.wipro.securityjwt.repository;
import com.wipro.securityjwt.entity.ERole;
import com.wipro.securityjwt.entity.Role;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;


public interface RoleRepository extends JpaRepository<Role, Long> {
	Optional<Role> findByName(ERole name);

}
