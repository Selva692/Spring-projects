package com.wipro.securityjwt.entity;

public enum Erole {
	 ROLE_USER,
	 ROLE_ADMIN
}
