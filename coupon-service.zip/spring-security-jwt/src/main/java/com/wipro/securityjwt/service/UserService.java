package com.wipro.securityjwt.service;
import com.wipro.securityjwt.dto.ApiResponse;

import java.util.List;
import java.util.Map;
public interface UserService {
	List<Map<String, Object>> getAllUsers();

    Map<String, Object> getUserById(Long id);

    ApiResponse deleteUser(Long id);

    ApiResponse setEnabled(Long id, boolean enabled);

}
