package com.wipro.securityjwt.exception;

public class ResourceNotFoundException {
	 public ResourceNotFoundException(String message) {
	        super(message);
	    }

}
