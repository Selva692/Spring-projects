package com.wipro.securityjwt.dto;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import java.util.List;
import lombok.NoArgsConstructor;


@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class JwtResponse {
	 @Builder.Default
	    private String tokenType = "Bearer";

	    private String accessToken;
	    private Long id;
	    private String username;
	    private String email;
	    private List<String> roles;


}
