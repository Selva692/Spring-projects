package com.wipro.employee.exception;

public class EmployeeIdNotFoundException extends RuntimeException{
	private int id;
	
	public EmployeeIdNotFoundException(int id) {
		this.id=id;
	}
	
	@Override
	public String toString() {
		return "Employee Id" + id + "is not found";
	}

}
