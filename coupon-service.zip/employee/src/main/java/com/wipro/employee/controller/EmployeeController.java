package com.wipro.employee.controller;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.wipro.employee.dto.request.Employee;
import com.wipro.employee.service.EmployeeService;
@Tag(name="Employee",description="Employee management APIs")
@RequestMapping("api/v1/employees")
@RestController
public class EmployeeController {
	@Autowired
	private EmployeeService employeeService;
	
	public EmployeeController(@Autowired EmployeeService employeeservice, EmployeeService employeeService) {
		super();
		this.employeeService = employeeService;
	}
	
	@PostMapping
	
	public ResponseEntity<Employee> saveEmployee(@RequestBody Employee employee){
		return new ResponseEntity<Employee>(employeeService.saveEmployee(employee),HttpStatus.CREATED);
	}
	@Operation(summary="Get employee by id")
	@GetMapping("/{id}")
	public ResponseEntity<Employee> getEmployeeById(@PathVariable int id){
		return new ResponseEntity<Employee>(employeeService.findById(id),HttpStatus.OK);
	}
	
	@GetMapping
	public ResponseEntity<List<Employee>>getAllEmployee(){
		return new ResponseEntity<List<Employee>>(employeeService.findAll(),HttpStatus.OK);
	}
	@Operation(summary="Get employee by firstname")
	@GetMapping("/firstname/{firstName}")
	public ResponseEntity<Employee>findByFirstName(@PathVariable String firstName){
		
		return new ResponseEntity<Employee>(employeeService.findByFirstName(firstName),HttpStatus.OK);
	}
	
}
