package com.wipro.employee.controller;


import com.fasterxml.jackson.databind.ObjectMapper;
import com.wipro.employee.dto.request.Employee;
import com.wipro.employee.exception.EmployeeIdNotFoundException;
import com.wipro.employee.service.EmployeeService;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.http.MediaType;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.web.servlet.MockMvc;

import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;
import static org.hamcrest.collection.IsCollectionWithSize.hasSize;
import java.util.Arrays;
import java.util.List;
import java.util.Random;
import java.util.UUID;

@WebMvcTest(EmployeeController.class)
public class EmployeeControllerTest {
	@MockitoBean
    //@MockBean // used to create mock object /dummy object
    private EmployeeService employeeService;

    @Autowired
    private MockMvc mockMvc; // to test the API 

    @Autowired
    private ObjectMapper objectMapper;
    private final Random random=new Random();
    private String randomText(int length) {
    	return UUID.randomUUID().toString().replace("-", "").substring(0,length);
    }
    
	private Employee testCreateEmployee() {
    	Employee employee = new Employee();
		employee.setEmpId(random.nextInt(1000)+1);
    	employee.setFirstName(randomText(8));
    	employee.setLastName(randomText(8));
    	employee.setEmail(randomText(8)+"@"+randomText(5)+".com");
    	return employee;
    }
        @Test // test case
        void testSaveEmployee() throws Exception{
        	Employee actualEmployeeRequestBody=testCreateEmployee();
        when(employeeService.saveEmployee(any(Employee.class))).thenReturn(actualEmployeeRequestBody);

        // act & assert
        mockMvc.perform(post("/api/v1/employees")
                    .contentType(MediaType.APPLICATION_JSON)
                    .content(objectMapper.writeValueAsString(actualEmployeeRequestBody)))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.firstName").value(actualEmployeeRequestBody.getFirstName()))
                .andExpect(jsonPath("$.lastName").value(actualEmployeeRequestBody.getLastName()))
                .andExpect(jsonPath("$.email").value(actualEmployeeRequestBody.getEmail()));
        /*
          {
           title :"Controller test task"
           }
         */
                //.andExpect(jsonPath("$.source").value("Chennai"))
                //.andExpect(jsonPath("$.destination").value("Bangalore"));

    }
}