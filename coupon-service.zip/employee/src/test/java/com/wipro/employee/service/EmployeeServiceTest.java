package com.wipro.employee.service;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;

import com.wipro.employee.dto.request.Employee;
import com.wipro.employee.exception.EmployeeIdNotFoundException;
import com.wipro.employee.repository.EmployeeRepository;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class EmployeeServiceTest {
    @Mock
    private EmployeeRepository employeeRepository;

    @InjectMocks
    private EmployeeService employeeService;

    @Test
    void testGetAllemployees() {
        // arrange
        List<Employee> employees = Arrays.asList(
                new Employee(),
                new Employee()
        );

        //when(EmployeeRepository.findAll()).thenReturn(employees);
    }
}