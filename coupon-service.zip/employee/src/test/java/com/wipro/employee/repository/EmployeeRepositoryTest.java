package com.wipro.employee.repository;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;

import com.wipro.employee.dto.request.Employee;

import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;

@DataJpaTest
public class EmployeeRepositoryTest {

@Autowired
EmployeeRepository employeeRepository;

@Test
void testSaveEmployee() {
// arrange
Employee employee = new Employee();

// act
Employee actualSavedEmployee = new Employee();

// assert
assertNotNull(actualSavedEmployee);
String expectedSavedEmployeeTitle="Test employee";
//assertEquals(expectedSavedEmployeeTitle, ((Object) actualSavedEmployee).getTitle());
}
}