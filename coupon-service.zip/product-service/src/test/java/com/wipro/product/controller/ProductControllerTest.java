package com.wipro.product.controller;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.wipro.product.controller.ProductController;
import com.wipro.product.dto.request.Product;
import com.wipro.product.exception.ProductIdNotFoundException;
import com.wipro.product.service.ProductService;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.http.MediaType;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.web.servlet.MockMvc;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;
import static org.hamcrest.collection.IsCollectionWithSize.hasSize;
import java.util.Arrays;
import java.util.List;
import java.util.Random;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;
@WebMvcTest(ProductController.class)

class ProductControllerTest {
	@MockitoBean
    //@MockBean // used to create mock object /dummy object
    private ProductService productService;

    @Autowired
    private MockMvc mockMvc; // to test the API 

    @Autowired
    private ObjectMapper objectMapper;
    private final Random random=new Random();
    private String randomText(int length) {
    	return UUID.randomUUID().toString().replace("-", "").substring(0,length);
    }
    
	private Product testCreateProduct() {
    	Product product = new Product();
    	product.setId(random.nextInt(1000)+1);
    	product.setName(randomText(8));
    	product.setPrice(random.nextInt(1000)+1);
    	product.setQuantity(random.nextInt(1000)+1);
    	return product;
    }
        @Test // test case
        void testSaveProduct() throws Exception{
        	Product actualProductRequestBody=testCreateProduct();
        when(productService.saveProduct(any(Product.class))).thenReturn(actualProductRequestBody);

        // act & assert
        mockMvc.perform(post("/api/v1/employees")
                    .contentType(MediaType.APPLICATION_JSON)
                    .content(objectMapper.writeValueAsString(actualProductRequestBody)))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.name").value(actualProductRequestBody.getName()))
                .andExpect(jsonPath("$.price").value(actualProductRequestBody.getPrice()))
                .andExpect(jsonPath("$.quantity").value(actualProductRequestBody.getQuantity()));
	}

}
