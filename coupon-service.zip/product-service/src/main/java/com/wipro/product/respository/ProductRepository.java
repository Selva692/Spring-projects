package com.wipro.product.respository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.wipro.product.dto.request.Product;
@Repository

public interface ProductRepository extends JpaRepository<Product,Integer> {
	Product findByName(String name);
	

}
