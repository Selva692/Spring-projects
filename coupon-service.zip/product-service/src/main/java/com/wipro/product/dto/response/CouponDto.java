package com.wipro.product.dto.response;

import jakarta.persistence.Column;

public class CouponDto {
	private int Id;
	@Column(name="code")
	private String code;
	@Column(name="discount")
	private int discount;
	public int getId() {
		return Id;
	}
	public void setId(int Id) {
		this.Id = Id;
	}
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	public int getDiscount(int discount) {
		return discount;
	}
	public void setDiscount(int discount) {
		this.discount = discount;
	}

}
