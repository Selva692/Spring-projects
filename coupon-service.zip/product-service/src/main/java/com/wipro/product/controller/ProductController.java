package com.wipro.product.controller;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.wipro.product.dto.request.Product;
import com.wipro.product.service.ProductService;
//@Tag(name="Product",description="Product management APIs")
@RequestMapping("api/v1/products")
@RestController
public class ProductController {
	@Autowired
	private ProductService productService;
	
	public ProductController(@Autowired ProductService productservice, ProductService productService) {
		super();
		this.productService = productService;
	}
	
	@PostMapping
	
	public ResponseEntity<Product> saveProduct(@RequestBody Product product){
		return new ResponseEntity<Product>(productService.saveProduct(product),HttpStatus.CREATED);
	}
	@Operation(summary="Get product by id")
	@GetMapping("/{id}")
	public ResponseEntity<Product> getProductById(@PathVariable int id){
		return new ResponseEntity<Product>(productService.findById(id),HttpStatus.OK);
	}
	
	@GetMapping
	public ResponseEntity<List<Product>>getAllProduct(){
		return new ResponseEntity<List<Product>>(productService.findAll(),HttpStatus.OK);
	}
	@Operation(summary="Get product by productname")
	@GetMapping("/productname/{productName}")
	public ResponseEntity<Product>findByFirstName(@PathVariable String firstName){
		
		return new ResponseEntity<Product>(productService.findByName(firstName),HttpStatus.OK);
	}
	
}

