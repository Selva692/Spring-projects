package com.wipro.product.exception;

public class ProductIdNotFoundException extends RuntimeException {
	private int id;
	
	public ProductIdNotFoundException(int id) {
		this.id=id;
	}
	
	@Override
	public String toString() {
		return "Employee Id" + id + "is not found";
	}

}
