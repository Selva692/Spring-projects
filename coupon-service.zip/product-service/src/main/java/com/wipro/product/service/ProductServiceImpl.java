package com.wipro.product.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.wipro.product.dto.request.Product;
import com.wipro.product.exception.ProductIdNotFoundException;
import com.wipro.product.respository.ProductRepository;

import jakarta.transaction.Transactional;
@Service

public class ProductServiceImpl implements ProductService{
	@Autowired
	private ProductRepository productRepository;
	
	public ProductServiceImpl(@Autowired ProductRepository productRepository) {
		super();
		this.productRepository=productRepository;
	}
	
	@Transactional
	public Product saveProduct(Product product) {
		return productRepository.save(product);
	}
	
	public Product findById(int id) {
		Optional<Product> optionalContainer=productRepository.findById(id);
		if(optionalContainer.isPresent())
			return optionalContainer.get();
		else
			throw new ProductIdNotFoundException(id);
	}
	
	public List<Product> findAll(){
		return productRepository.findAll();
	}
	
	public Product findByName(String name) {
		return productRepository.findByName(name);
	}
}
